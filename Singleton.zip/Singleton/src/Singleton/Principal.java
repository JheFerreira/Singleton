/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Singleton;

/**
 *
 * @author JéssicaFerreira
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
        Login login1 = Login.getInstance();
        Login login2 = Login.getInstance();
        
        
        System.out.println(login1);
        System.out.println(login2);
        
        
        if (login1==login2){
            System.out.println("Os objetos estão no mesmo endereço, portanto eles são o mesmo objeto");
        }else{
            System.out.println("Os objetos estão em endereços diferentes, portanto, são objetos distintos");
        }
          //Login login = new Login(); Se tentar stanciar aqui, ocorre erro.

    }
    
}
