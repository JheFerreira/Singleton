/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Singleton;

/**
 *
 * @author JéssicaFerreira
 */
public class Login {
    
    private static Login login;
    private String usuario;
    private String senha;

    private Login(){}

    public static Login getInstance(){
        if(login == null){
        return new Login();
        }else{
        return login;
        }       
    }
}


  
